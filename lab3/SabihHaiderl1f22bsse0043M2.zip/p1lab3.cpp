//#include<iostream>
//using namespace std;
//int main()
//{
//	int i;
//	for (i = 1; i <= 40; i++)
//	{
//		cout << "Sabih Haider" << endl << "University of central Punjab" << endl;
//	}
//	system("pause");
//	return 0;
//}